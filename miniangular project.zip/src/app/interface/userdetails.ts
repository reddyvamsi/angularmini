export interface Userdetails{
    username?: string;
    password?: string;
  } 